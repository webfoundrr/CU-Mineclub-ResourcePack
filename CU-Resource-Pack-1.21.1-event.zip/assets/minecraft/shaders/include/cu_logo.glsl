// CU emblem PNG marker (250,254,251). Other glyphs use vanilla rendering.
bool cu_emblem(vec3 rgb) {
    return all(lessThan(abs(rgb - vec3(250.0,254.0,251.0)/255.0), vec3(0.001)));
}

float cu_logo_alpha(vec4 sampleColor) {
    bool title = all(lessThan(abs(sampleColor.rgb - vec3(249.0,252.0,254.0)/255.0), vec3(0.001)));
    // Font atlas neighbours are unrelated glyphs. Their alpha must never
    // enter the logo's smoothing kernel, even at the edge of the quad.
    return (cu_emblem(sampleColor.rgb) || title) ? sampleColor.a : 0.0;
}

float cu_bilinear_alpha(sampler2D atlas, vec2 uv) {
    ivec2 size = textureSize(atlas, 0);
    vec2 p = uv * vec2(size) - vec2(0.5);
    ivec2 base = ivec2(floor(p));
    vec2 w = fract(p);
    ivec2 lo = ivec2(0);
    ivec2 hi = size - ivec2(1);
    float a = cu_logo_alpha(texelFetch(atlas, clamp(base, lo, hi), 0));
    float b = cu_logo_alpha(texelFetch(atlas, clamp(base + ivec2(1,0), lo, hi), 0));
    float c = cu_logo_alpha(texelFetch(atlas, clamp(base + ivec2(0,1), lo, hi), 0));
    float d = cu_logo_alpha(texelFetch(atlas, clamp(base + ivec2(1,1), lo, hi), 0));
    return mix(mix(a,b,w.x), mix(c,d,w.x), w.y);
}

float cu_coverage(sampler2D atlas, vec2 uv, vec2 dx, vec2 dy) {
    return 0.25 * (
        cu_bilinear_alpha(atlas, uv - dx - dy) +
        cu_bilinear_alpha(atlas, uv + dx - dy) +
        cu_bilinear_alpha(atlas, uv - dx + dy) +
        cu_bilinear_alpha(atlas, uv + dx + dy));
}
