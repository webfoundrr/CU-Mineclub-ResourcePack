#version 150
uniform sampler2D Sampler0;
uniform vec4 ColorModulator;
uniform mat4 ProjMat;
in vec2 texCoord0;
flat in int cuInventory;
flat in int cuBookOpen;
flat in int cuWidget;
flat in int cuFirstPause;
flat in vec4 cuPauseRect;
flat in vec4 cuPauseButton;
in vec2 cuWidgetUV;
in vec2 cuScreenXY;
out vec4 fragColor;
float roundedBox(vec2 p,vec2 halfSize,float radius) {
    vec2 q=abs(p)-halfSize+radius;
    return length(max(q,vec2(0.0)))+min(max(q.x,q.y),0.0)-radius;
}
float coverage(float d) {
    float aa=max(fwidth(d),0.25);
    return 1.0-smoothstep(-aa,aa,d);
}
vec4 premultiply(vec4 c) { return vec4(c.rgb*c.a,c.a); }
vec4 filtered(vec2 uv) {
    ivec2 size=textureSize(Sampler0,0);
    vec2 p=uv*vec2(size)-0.5;
    ivec2 b=ivec2(floor(p));
    vec2 w=fract(p);
    ivec2 hi=size-1;
    vec4 a=premultiply(texelFetch(Sampler0,clamp(b,ivec2(0),hi),0));
    vec4 c=premultiply(texelFetch(Sampler0,clamp(b+ivec2(1,0),ivec2(0),hi),0));
    vec4 d=premultiply(texelFetch(Sampler0,clamp(b+ivec2(0,1),ivec2(0),hi),0));
    vec4 e=premultiply(texelFetch(Sampler0,clamp(b+ivec2(1),ivec2(0),hi),0));
    return mix(mix(a,c,w.x),mix(d,e,w.x),w.y);
}
void main() {
    vec4 c;
    if(cuWidget>0) {
        vec2 size=vec2(abs(dFdx(cuScreenXY.x)/dFdx(cuWidgetUV.x)),abs(dFdy(cuScreenXY.y)/dFdy(cuWidgetUV.y)));
        vec4 box=vec4(cuScreenXY-cuWidgetUV*size,size);
        if(cuFirstPause==1) box=cuPauseButton;
        bool sliderTrack=cuWidget==4 || cuWidget==5;
        bool sliderHandle=cuWidget==6 || cuWidget==7;
        float radius=sliderHandle ? 2.5 : 4.0;
        float d=roundedBox(cuScreenXY-(box.xy+box.zw*0.5),box.zw*0.5-0.5,radius);
        float buttonAlpha=coverage(d);
        float t=clamp((cuScreenXY.y-box.y)/box.w,0.0,1.0);
        bool hover=cuWidget==2 || cuWidget==5 || cuWidget==7;
        vec3 top=hover ? vec3(106.0,79.0,219.0)/255.0 : vec3(0.20,0.19,0.25);
        vec3 bottom=hover ? vec3(77.0,54.0,181.0)/255.0 : vec3(0.15,0.15,0.21);
        vec3 border=hover ? vec3(185.0,154.0,255.0)/255.0 : vec3(0.42,0.38,0.54);
        // Reconstruct the vanilla pause row from orthographic screen dimensions.
        // These are uniform across the quad and preserve native hover semantics.
        if(cuFirstPause==1) {
            top=hover ? vec3(0.0,166.0,81.0)/255.0 : vec3(0.0,143.0,70.0)/255.0;
            bottom=top;
            border=hover ? vec3(0.36,0.88,0.59) : vec3(0.19,0.67,0.41);
        }
        float screenWidth=2.0/ProjMat[0][0];
        float screenHeight=-2.0/ProjMat[1][1];
        vec2 guiSize=ceil(vec2(screenWidth,screenHeight)-0.01);
        vec2 exitOrigin=vec2(floor((guiSize.x-212.0)*0.5)+4.0,trunc((guiSize.y-166.0)*0.25)+146.0);
        bool exitButton=cuWidget<=3 && all(lessThan(abs(box.xy-exitOrigin),vec2(1.1))) && all(lessThan(abs(box.zw-vec2(204.0,20.0)),vec2(0.25)));
        if(exitButton) {
            top=hover ? vec3(0.57,0.23,0.26) : vec3(0.49,0.19,0.22);
            bottom=hover ? vec3(0.47,0.17,0.21) : vec3(0.39,0.13,0.17);
            border=hover ? vec3(0.76,0.38,0.44) : vec3(0.67,0.31,0.37);
        }
        if(cuWidget==3) {top=vec3(0.14,0.14,0.18);bottom=vec3(0.10,0.10,0.14);border=vec3(0.27,0.26,0.34);}
        if(sliderTrack) {
            top=hover ? vec3(58.0,49.0,81.0)/255.0 : vec3(41.0,43.0,61.0)/255.0;
            bottom=hover ? vec3(38.0,32.0,58.0)/255.0 : vec3(26.0,27.0,40.0)/255.0;
            border=hover ? vec3(185.0,154.0,255.0)/255.0 : vec3(105.0,88.0,143.0)/255.0;
        }
        if(sliderHandle) {
            top=hover ? vec3(154.0,117.0,245.0)/255.0 : vec3(117.0,83.0,202.0)/255.0;
            bottom=hover ? vec3(110.0,73.0,205.0)/255.0 : vec3(80.0,51.0,150.0)/255.0;
            border=hover ? vec3(217.0,196.0,255.0)/255.0 : vec3(172.0,144.0,227.0)/255.0;
        }
        vec3 button=mix(top,bottom,t);
        float edge=1.0-smoothstep(0.4,1.2,abs(d));
        button=mix(button,border,edge*0.7);
        if(sliderHandle) {
            vec2 local=cuScreenXY-(box.xy+box.zw*0.5);
            float grip=(1.0-smoothstep(0.3,0.8,abs(local.x)))*(1.0-smoothstep(3.0,4.0,abs(local.y)));
            button=mix(button,vec3(0.87,0.81,1.0),grip*0.45);
        }
        c=vec4(button,buttonAlpha);
        if(cuFirstPause==1) {
            float pd=roundedBox(cuScreenXY-(cuPauseRect.xy+cuPauseRect.zw*0.5),cuPauseRect.zw*0.5-0.5,10.0);
            float pt=clamp((cuScreenXY.y-cuPauseRect.y)/cuPauseRect.w,0.0,1.0);
            vec3 panel=mix(vec3(41.0,43.0,68.0),vec3(16.0,18.0,29.0),pt)/255.0;
            float pe=1.0-smoothstep(0.4,1.1,abs(pd));
            panel=mix(panel,vec3(163.0,130.0,238.0)/255.0,pe*0.8);
            float pa=coverage(pd)*0.96;
            c=vec4(mix(panel,button,buttonAlpha),max(pa,buttonAlpha));
        }
    } else if(cuInventory>0) {
        vec2 dx=dFdx(texCoord0)*0.25;
        vec2 dy=dFdy(texCoord0)*0.25;
        c=0.25*(filtered(texCoord0-dx-dy)+filtered(texCoord0+dx-dy)+filtered(texCoord0-dx+dy)+filtered(texCoord0+dx+dy));
        if(c.a>0.0) c.rgb/=c.a;
        // Native recipe-book positioning leaves a 4px gutter. Trim only the
        // extended body margin when it is open; keep slots and title intact.
        vec2 canvas=texCoord0*256.0;
        if(cuBookOpen==1 && canvas.y>=36.0) {
            if(canvas.x<10.0) discard;
            if(canvas.x<10.8) c=vec4(163.0/255.0,130.0/255.0,238.0/255.0,0.9);
        }
    } else c=texture(Sampler0,texCoord0);
    if(c.a<=0.003) discard;
    fragColor=c*ColorModulator;
}
