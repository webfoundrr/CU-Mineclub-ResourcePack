#version 150
#moj_import <fog.glsl>
in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;
uniform sampler2D Sampler0;
uniform sampler2D Sampler2;
uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform int FogShape;
out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;
flat out int cuPanel;
flat out int cuLogo;
flat out vec4 cuPanelRect;
flat out float cuButtonY;
out vec2 cuScreenXY;

void main() {
    int corner = gl_VertexID % 4;
    ivec2 inward = ivec2(corner >= 2 ? -1 : 0, (corner == 1 || corner == 2) ? -1 : 0);
    ivec2 atlasSize = textureSize(Sampler0, 0);
    ivec2 probe = clamp(ivec2(UV0 * vec2(atlasSize)) + inward, ivec2(0), atlasSize - ivec2(1));
    vec3 rgb = texelFetch(Sampler0, probe, 0).rgb;
    bool panel = all(lessThan(abs(rgb - vec3(13.0,29.0,47.0)/255.0), vec3(0.001)));
    bool title = all(lessThan(abs(rgb - vec3(249.0,252.0,254.0)/255.0), vec3(0.001)));
    bool emblem = all(lessThan(abs(rgb - vec3(250.0,254.0,251.0)/255.0), vec3(0.001)));
    cuLogo = (title || emblem) ? 1 : 0;
    bool resume = all(lessThan(abs(rgb - vec3(14.0,30.0,48.0)/255.0), vec3(0.001)));
    bool disconnect = all(lessThan(abs(rgb - vec3(15.0,31.0,49.0)/255.0), vec3(0.001)));
    vec4 pos = ModelViewMat * vec4(Position,1.0);
    float width = 2.0 / ProjMat[0][0];
    float height = -2.0 / ProjMat[1][1];
    // Vanilla 1.21.1 PauseScreen: grid height 166, alignment Y 0.25,
    // first-row top padding 50; five button rows, spacing 4.
    vec2 guiSize = ceil(vec2(width,height)-0.01);
    float firstX = floor((guiSize.x-212.0)*0.5)+4.0;
    float firstY = trunc((guiSize.y - 166.0) * 0.25) + 50.0;
    cuPanelRect = vec4(firstX-14.0, firstY-45.0, 232.0, 173.0);
    cuButtonY = firstY;
    cuPanel = panel ? 1 : 0;
    if (resume || disconnect) {
        cuPanel = resume ? 2 : 3;
        cuPanelRect = vec4(firstX, firstY+(disconnect ? 96.0 : 0.0), 204.0, 20.0);
    }
    if (panel || resume || disconnect) {
        vec2 side = vec2(corner >= 2 ? 1.0 : 0.0, (corner == 1 || corner == 2) ? 1.0 : 0.0);
        pos.xy = cuPanelRect.xy + side * cuPanelRect.zw;
    } else if (title) {
        // Bitmap top is y=39: StringWidget y=40 and ascent=8.
        pos.y += firstY - 32.0 - 39.0;
    }
    gl_Position = ProjMat * pos;
    vertexDistance = fog_distance(Position, FogShape);
    vertexColor = Color * texelFetch(Sampler2, UV2 / 16, 0);
    // Native container titles (including custom names) use #404040.
    // Recolor that label tone only in the orthographic GUI projection.
    if(abs(ProjMat[3][3]-1.0)<0.001 && all(lessThan(abs(Color.rgb-vec3(64.0/255.0)),vec3(0.001)))) {
        vertexColor.rgb=vec3(198.0,189.0,219.0)/255.0;
    }
    texCoord0 = UV0;
    cuScreenXY = pos.xy;
}
