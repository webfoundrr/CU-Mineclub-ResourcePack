#version 150

#moj_import <cu_logo.glsl>

uniform sampler2D Sampler0;
uniform vec4 ColorModulator;
in vec4 vertexColor;
in vec2 texCoord0;
out vec4 fragColor;

void main() {
    vec4 raw = texture(Sampler0, texCoord0);
    vec2 dx = dFdx(texCoord0) * 0.25;
    vec2 dy = dFdy(texCoord0) * 0.25;
    bool emblem = cu_emblem(raw.rgb);
    vec4 color = raw * vertexColor;
    if (emblem) {
        if (max(vertexColor.r, max(vertexColor.g, vertexColor.b)) < 0.5) discard;
        color = vec4(1.0,1.0,1.0,cu_coverage(Sampler0,texCoord0,dx,dy)) * vertexColor;
    }
    if (color.a < (emblem ? 0.003 : 0.1)) discard;
    fragColor = color * ColorModulator;
}
