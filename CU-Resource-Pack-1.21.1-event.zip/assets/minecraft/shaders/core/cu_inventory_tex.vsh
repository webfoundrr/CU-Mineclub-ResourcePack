#version 150
in vec3 Position;
in vec2 UV0;
uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform sampler2D Sampler0;
out vec2 texCoord0;
flat out int cuInventory;
flat out int cuBookOpen;
flat out int cuWidget;
flat out int cuFirstPause;
flat out vec4 cuPauseRect;
flat out vec4 cuPauseButton;
out vec2 cuWidgetUV;
out vec2 cuScreenXY;
void main() {
    vec4 p=ModelViewMat*vec4(Position,1.0);
    ivec2 size=textureSize(Sampler0,0);
    vec3 marker=texelFetch(Sampler0,ivec2(0),0).rgb;
    bool inventory=size==ivec2(1024) && all(lessThan(abs(marker-vec3(21.0,37.0,53.0)/255.0),vec3(0.001)));
    bool recipes=size==ivec2(1024) && all(lessThan(abs(marker-vec3(25.0,41.0,57.0)/255.0),vec3(0.001)));
    bool container=(size==ivec2(1024) || size==ivec2(2048,1024)) && all(lessThan(abs(marker-vec3(27.0,43.0,59.0)/255.0),vec3(0.001)));
    cuInventory=inventory ? 1 : (recipes ? 2 : (container ? 3 : 0));
    cuBookOpen=0;
    cuWidget=0;
    cuFirstPause=0;
    cuPauseRect=vec4(0.0);
    cuPauseButton=vec4(0.0);
    int corner=gl_VertexID%4;
    vec2 side=vec2(corner>=2 ? 1.0 : 0.0,(corner==1 || corner==2) ? 1.0 : 0.0);
    cuWidgetUV=side;
    ivec2 inward=ivec2(side.x>0.5 ? -1 : 1,side.y>0.5 ? -1 : 1);
    ivec2 probe=clamp(ivec2(UV0*vec2(size))+inward,ivec2(0),size-1);
    vec3 rgb=texelFetch(Sampler0,probe,0).rgb;
    for(int state=1;state<=7;state++) {
        if(all(lessThan(abs(rgb-vec3(30.0+float(state),46.0+float(state),62.0+float(state))/255.0),vec3(0.001)))) cuWidget=state;
    }
    texCoord0=UV0;
    float width=2.0/ProjMat[0][0];
    float height=-2.0/ProjMat[1][1];
    // Window GUI dimensions are rounded up; undo projection float error first.
    float guiWidth=ceil(width-0.01);
    float guiHeight=ceil(height-0.01);
    float firstX=floor((guiWidth-212.0)*0.5)+4.0;
    float firstY=trunc((guiHeight-166.0)*0.25)+50.0;
    if(cuWidget>0 && cuWidget<=3) {
        vec2 origin=p.xy-side*vec2(204.0,20.0);
        bool firstEdge=all(lessThan(abs(origin-vec2(firstX,firstY)),vec2(1.1)));
        if(firstEdge) {
            cuFirstPause=1;
            cuPauseRect=vec4(origin+vec2(-14.0,-45.0),232.0,173.0);
            cuPauseButton=vec4(origin,204.0,20.0);
            p.xy=cuPauseRect.xy+side*cuPauseRect.zw;
        }
    }
    if(inventory) {
        float nativeLeft=p.x-UV0.x*256.0;
        cuBookOpen=nativeLeft>floor((width-176.0)*0.5)+30.0 ? 1 : 0;
        // Extend only the decorative background: 12 px to either side,
        // 36 px above and 6 px below. Contents and hitboxes stay native.
        // Native slots, the player model, recipe button and hitboxes stay put.
        float row=UV0.y*256.0/166.0;
        float col=UV0.x*256.0/176.0;
        p.x+=-12.0+24.0*col;
        p.y+=-36.0+42.0*row;
        texCoord0.x*=200.0/176.0;
        texCoord0.y*=208.0/166.0;
    }
    cuScreenXY=p.xy;
    gl_Position=ProjMat*p;
}
