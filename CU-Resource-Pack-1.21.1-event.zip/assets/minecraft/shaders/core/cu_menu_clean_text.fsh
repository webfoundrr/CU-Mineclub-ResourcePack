#version 150
#moj_import <fog.glsl>
#moj_import <cu_menu_clean_logo.glsl>
uniform sampler2D Sampler0;
uniform vec4 ColorModulator;
uniform float FogStart;
uniform float FogEnd;
uniform vec4 FogColor;
in float vertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;
flat in int cuPanel;
flat in int cuLogo;
flat in vec4 cuPanelRect;
flat in float cuButtonY;
in vec2 cuScreenXY;
out vec4 fragColor;

float roundedBox(vec2 p, vec2 halfSize, float radius) {
    vec2 q=abs(p)-halfSize+vec2(radius);
    return length(max(q,vec2(0.0)))+min(max(q.x,q.y),0.0)-radius;
}
void main() {
    vec2 dx=dFdx(texCoord0)*0.25;
    vec2 dy=dFdy(texCoord0)*0.25;
    if (cuPanel==2 || cuPanel==3) {
        if(max(vertexColor.r,max(vertexColor.g,vertexColor.b))<0.5) discard;
        vec2 p=cuScreenXY;
        float d=roundedBox(p-(cuPanelRect.xy+cuPanelRect.zw*0.5),cuPanelRect.zw*0.5-vec2(0.5),4.0);
        float aa=max(fwidth(d),0.35);
        float coverage=1.0-smoothstep(-aa,aa,d);
        float t=clamp((p.y-cuPanelRect.y)/cuPanelRect.w,0.0,1.0);
        vec3 green=vec3(0.0,166.0,81.0)/255.0; // #00A651
        vec3 top=cuPanel==2 ? green : vec3(0.64,0.20,0.25);
        vec3 bottom=cuPanel==2 ? green : vec3(0.40,0.10,0.14);
        vec3 color=mix(top,bottom,t);
        float edge=1.0-smoothstep(0.4,1.2,abs(d));
        color=mix(color,cuPanel==2 ? vec3(0.35,0.84,0.57) : vec3(0.88,0.40,0.43),edge*0.55);
        // Prefix marker is drawn before the ordinary label; translucency
        // preserves the underlying widget's hover feedback.
        fragColor=vec4(color,coverage*(cuPanel==2 ? 1.0 : 0.92))*ColorModulator;
        if(fragColor.a<0.003) discard;
        return;
    }
    if (cuPanel==1) {
        if(max(vertexColor.r,max(vertexColor.g,vertexColor.b))<0.5) discard;
        vec2 p=cuScreenXY;
        // The marker now prefixes the first button label. GuiGraphics
        // flushes that label before rendering the subsequent widgets.
        // Draw a continuous panel; the next marker repaints the first button.
        float d=roundedBox(p-(cuPanelRect.xy+cuPanelRect.zw*0.5),cuPanelRect.zw*0.5-vec2(0.8),10.0);
        float aa=max(fwidth(d),0.35);
        float coverage=1.0-smoothstep(-aa,aa,d);
        float edge=1.0-smoothstep(0.8,1.5,abs(d));
        float t=clamp((p.y-cuPanelRect.y)/cuPanelRect.w,0.0,1.0);
        vec3 surface=mix(vec3(0.12,0.13,0.21),vec3(0.055,0.063,0.095),t);
        vec3 color=mix(surface,vec3(0.43,0.36,0.78),edge*0.65);
        fragColor=vec4(color,coverage*0.91)*ColorModulator;
        if(fragColor.a<0.003) discard;
        return;
    }
    vec4 raw=texture(Sampler0,texCoord0);
    bool emblem=cuLogo!=0;
    vec4 color=raw*vertexColor*ColorModulator;
    if(emblem) {
        if(max(vertexColor.r,max(vertexColor.g,vertexColor.b))<0.5) discard;
        color=vec4(1.0,1.0,1.0,cu_coverage(Sampler0,texCoord0,dx,dy))*vertexColor*ColorModulator;
    }
    if(color.a<(emblem?0.003:0.1)) discard;
    fragColor=linear_fog(color,vertexDistance,FogStart,FogEnd,FogColor);
}
